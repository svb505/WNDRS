By downloading or using this font, you agree to the terms outlined in our Product Usage Agreement.

🔹 Personal Use Only
This font is free for personal use.
Commercial use is strictly prohibited.

🔹 Want the Full Version?
Get access to the complete set of glyphs and a commercial license here:
👉 https://salamahtype.com

Note: Only the full version includes all glyphs and extra features.

🔹 Explore More Fonts
Discover more premium fonts and bundles at:
👉 https://salamahtype.com

🔹 Support Us
If you’d like to support the creator, donations are appreciated!
👉 https://paypal.me/aswangga

🔹 Need Help or Have Questions?
Feel free to contact us:
📧 salamahtype@gmail.com
📧 aswangga@salamahtype.com